.. ceph-ansible documentation master file, created by
   sphinx-quickstart on Wed Apr  5 11:55:38 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ceph-ansible
============
Ansible playbooks for Ceph, the distributed filesystem.


Testing
=======

* :doc:`Testing with ceph-ansible <testing/index>`
* :doc:`Glossary <testing/glossary>`


OSDs
====

MONs
====

RGW
===

Configuration
=============

Docker
======
